package br.com.etechoracio.boaviagemapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoaViagemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaViagemApiApplication.class, args);
	}

}
